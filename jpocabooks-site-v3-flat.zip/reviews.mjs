// J. POCA Books - live reviews
// GET  -> list of posted reviews, newest first
// POST -> post a review (goes live at once), and a copy is emailed through the Netlify "review" form notification
// GET ?remove=ID&key=REVIEW_KEY -> take a review down (the link is in the notification email)
import { getStore } from '@netlify/blobs';

const STORE = 'reviews';
const KEY = 'list';
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const clean = (s, max) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, max);

async function load(store) {
  const rows = await store.get(KEY, { type: 'json', consistency: 'strong' });
  return Array.isArray(rows) ? rows : [];
}

async function notify(review, origin) {
  const key = process.env.REVIEW_KEY || '';
  const removeLink = key ? `${origin}/.netlify/functions/reviews?remove=${review.id}&key=${encodeURIComponent(key)}` : 'Set REVIEW_KEY in Netlify to get a remove link here.';
  const body = new URLSearchParams({ 'form-name': 'review', name: review.name, book: review.book, rating: String(review.rating), review: review.text, remove: removeLink }).toString();
  try { await fetch(origin + '/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body }); } catch (e) { /* the review is live either way */ }
}

export default async (req) => {
  const store = getStore({ name: STORE, consistency: 'strong' });
  const url = new URL(req.url);
  const origin = process.env.URL || url.origin;

  if (req.method === 'GET') {
    const remove = url.searchParams.get('remove');
    if (remove) {
      const key = process.env.REVIEW_KEY || '';
      if (!key || url.searchParams.get('key') !== key) return new Response('Not allowed.', { status: 403 });
      const rows = await load(store);
      const kept = rows.filter((r) => r.id !== remove);
      await store.setJSON(KEY, kept);
      return new Response(kept.length === rows.length ? 'That review was already gone.' : 'Removed. It is off the site.', { status: 200, headers: { 'Content-Type': 'text/plain' } });
    }
    const rows = await load(store);
    return json(rows.slice().reverse().map(({ id, name, book, rating, text, ts }) => ({ id, name, book, rating, text, ts })));
  }

  if (req.method === 'POST') {
    let body = {};
    try { body = await req.json(); } catch (e) { return json({ ok: false, error: 'Bad request.' }, 400); }
    const name = clean(body.name, 60), book = clean(body.book, 80) || 'Throne Code', text = clean(body.text, 1200);
    const rating = Math.max(1, Math.min(5, parseInt(body.rating, 10) || 0));
    if (!name || !text) return json({ ok: false, error: 'Name and review are both needed.' }, 400);
    if (!parseInt(body.rating, 10)) return json({ ok: false, error: 'Tap a star to rate it first.' }, 400);
    const review = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7), name, book, rating, text, ts: new Date().toISOString() };
    const rows = await load(store);
    rows.push(review);
    await store.setJSON(KEY, rows);
    await notify(review, origin);
    return json({ ok: true, review });
  }

  return json({ ok: false, error: 'Method not allowed.' }, 405);
};
